///<reference path="References.js" />
if (window.Yoyo === undefined)
{
    window.Yoyo = {};   
}

Yoyo.NormalShader = function()
{
    Yoyo.Shader.call(this);

    this.m_vertexPositionAttribute;
    this.m_textureCoordAttribute;

    //Holds [u]niform location in the shader
    this.m_uProjMatrix;
    this.m_uMVMatrix; 
}

//Makes NormalShader inherit from Yoyo.Shader!
Yoyo.NormalShader.prototype = new Yoyo.Shader();

Yoyo.NormalShader.prototype.LoadVertexShader = function(a_gl)
{    
    this.m_vertexShader = Yoyo.GetShader(a_gl, "vertexShader");
}

Yoyo.NormalShader.prototype.LoadFragmentShader = function(a_gl)
{
    this.m_fragmentShader = Yoyo.GetShader(a_gl, "fragmentShader");
}

Yoyo.NormalShader.prototype.InitShader = function(a_gl)
{  
    if (a_gl === undefined || a_gl === null)
    {
        throw "Yoyo.Shader.InitShader: Needs a_gl object!";
    }
    
    this.LoadVertexShader(a_gl);
    this.LoadFragmentShader(a_gl);    
    
    this.m_shaderProgram = a_gl.createProgram();
    a_gl.attachShader(this.m_shaderProgram, this.m_vertexShader);
    a_gl.attachShader(this.m_shaderProgram, this.m_fragmentShader);
    a_gl.linkProgram(this.m_shaderProgram);
  
    // If creating the shader program failed, alert  
    if (!a_gl.getProgramParameter(this.m_shaderProgram, a_gl.LINK_STATUS)) 
    {
        throw "Yoyo.Shader.InitShader: Unable to initialize the shader program!";
    }
  
    a_gl.useProgram(this.m_shaderProgram);
  
    this.m_vertexPositionAttribute = a_gl.getAttribLocation(this.m_shaderProgram, "aVertexPosition");
    a_gl.enableVertexAttribArray(this.m_vertexPositionAttribute);
    
//    this.m_textureCoordAttribute = a_gl.getAttribLocation(this.m_shaderProgram, "aTextureCoord");
//    a_gl.enableVertexAttribArray(this.m_textureCoordAttribute);
    
    this.m_uProjMatrix = a_gl.getUniformLocation(this.m_shaderProgram, "uProjMatrix");
    
    this.m_uMVMatrix = a_gl.getUniformLocation(this.m_shaderProgram, "uMVMatrix");             
}

Yoyo.NormalShader.prototype.SetMatrixUniforms = function(a_gl,a_camera)
{
    //var pUniform = gl.getUniformLocation(shaderProgram, "uPMatrix");
    a_gl.uniformMatrix4fv(this.m_uProjMatrix, false, a_camera.m_projectionMatrix);

    a_gl.uniformMatrix4fv(this.m_uMVMatrix, false, a_camera.m_viewMatrix);
}

Yoyo.NormalShader.prototype.Draw = function(a_gl, a_model, a_camera)
{
    try
    {
        a_gl.bindBuffer(a_gl.ARRAY_BUFFER , a_model.m_vertexBuffer);
        a_gl.vertexAttribPointer(this.m_vertexPositionAttribute, a_model.m_vertexBuffer.itemSize, a_gl.FLOAT, false, 0 , 0);

        this.SetMatrixUniforms(a_gl,a_camera);
        a_gl.drawArrays(a_gl.TRIANGLES, 0 , a_model.m_vertexBuffer.numItems);
    }
    catch (e)
    {
        console.log(  e.message );
    }

}